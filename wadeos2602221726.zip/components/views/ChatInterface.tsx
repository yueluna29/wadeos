import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useStore } from '../../store';
import { Button } from '../ui/Button';
import { generateTextResponse, generateTTS, generateChatTitle } from '../../services/geminiService';
import { generateMinimaxTTS } from '../../services/minimaxService';
import { Message, ChatMode, ArchiveMessage, ChatArchive } from '../../types';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// Simple Icons
const Icons = {
  Plus: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>,
  Back: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>,
  Trash: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>,
  Volume: () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>,
  VolumeLarge: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>,
  Heart: ({ filled }: { filled: boolean }) => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>,
  Send: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>,
  Edit: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>,
  Refresh: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>,
  Copy: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>,
  ChevronLeft: () => <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>,
  ChevronRight: () => <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>,
  More: () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>,
  Check: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>,
  Brain: () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"></path><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"></path></svg>,
  Down: () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>,
  Up: () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>,
  Branch: () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="6" y1="3" x2="6" y2="15"></line><circle cx="18" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><path d="M18 9a9 9 0 0 1-9 9"></path></svg>,
  Stop: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="6" width="12" height="12" rx="2"></rect></svg>,
  Search: () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>,
  Map: () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon><line x1="8" y1="2" x2="8" y2="18"></line><line x1="16" y1="6" x2="16" y2="22"></line></svg>,
  Close: () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>,
  Pin: () => <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0-7-9-7-9-7s-9 0-9 7c0 1.5 2 5 9 13 7-8 9-11.5 9-13z"></path></svg>,
  Infinity: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 12c-2-2.67-4-4-6-4a4 4 0 1 0 0 8c2 0 4-1.33 6-4Zm0 0c2 2.67 4 4 6 4a4 4 0 1 0 0-8c-2 0-4 1.33-6 4Z"/></svg>,
  Smartphone: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/></svg>,
  Feather: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" x2="2" y1="8" y2="22"/><line x1="17.5" x2="9" y1="15" y2="15"/></svg>,
  Wave: () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="2" x2="12" y2="22"></line><line x1="17" y1="5" x2="17" y2="19"></line><line x1="7" y1="5" x2="7" y2="19"></line><line x1="22" y1="8" x2="22" y2="16"></line><line x1="2" y1="8" x2="2" y2="16"></line></svg>
};

// --- Long Press Hook ---
const useLongPress = (callback: () => void, ms = 500) => {
  const timerRef = useRef<ReturnType<typeof setTimeout>>(null);
  const isMoved = useRef(false);

  const start = () => {
    isMoved.current = false;
    timerRef.current = setTimeout(() => {
      // Vibrate if supported for feedback
      if (navigator.vibrate) navigator.vibrate(50);
      callback();
    }, ms);
  };

  const stop = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
  };

  const move = () => {
    isMoved.current = true;
    stop();
  };

  return {
    onMouseDown: start,
    onMouseUp: stop,
    onMouseLeave: stop,
    onTouchStart: start,
    onTouchEnd: stop,
    onTouchMove: move,
    onContextMenu: (e: React.MouseEvent) => {
      e.preventDefault(); // Prevent native right-click menu
      callback();
    }
  };
};

const MessageBubble = ({
  msg, settings, onSelect, isSMS, onPlayTTS, searchQuery
}: {
  msg: Message, settings: any, onSelect: (id: string) => void, isSMS: boolean, onPlayTTS: (text: string) => void, searchQuery?: string
}) => {
  const isLuna = msg.role === 'Luna';
  const [showThought, setShowThought] = useState(false);

  // Format helpers
  const formatTime = (ts: number) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const formatDate = (ts: number) => new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric' });

  // Long press bindings
  const longPressHandlers = useLongPress(() => onSelect(msg.id));

  // Determine Thinking Content
  const idx = msg.selectedIndex || 0;
  const thinkingContent = msg.variantsThinking?.[idx];

  // FIX FOR "|||": Replace separators with visual spacing before rendering
  const displayContent = msg.text.replace(/\|\|\|/g, '\n\n');

  // Custom markdown renderer with search highlighting
  const MarkdownWithHighlight = ({ content, query }: { content: string, query?: string }) => {
    const components = React.useMemo(() => {
      if (!query || !query.trim()) return {};

      return {
        p: ({ children, ...props }: any) => {
          const highlightText = (node: any): any => {
            if (typeof node === 'string') {
              const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
              const parts = node.split(regex);
              return parts.map((part: string, i: number) =>
                part.toLowerCase() === query.toLowerCase()
                  ? <mark key={i} style={{ backgroundColor: 'rgba(213, 143, 153, 0.35)', padding: '2px 4px', borderRadius: '4px', fontWeight: 'inherit' }}>{part}</mark>
                  : part
              );
            }
            if (Array.isArray(node)) {
              return node.map((child, i) => <React.Fragment key={i}>{highlightText(child)}</React.Fragment>);
            }
            return node;
          };

          return <p {...props}>{highlightText(children)}</p>;
        },
        strong: ({ children, ...props }: any) => {
          const highlightText = (node: any): any => {
            if (typeof node === 'string') {
              const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
              const parts = node.split(regex);
              return parts.map((part: string, i: number) =>
                part.toLowerCase() === query.toLowerCase()
                  ? <mark key={i} style={{ backgroundColor: 'rgba(213, 143, 153, 0.35)', padding: '2px 4px', borderRadius: '4px', fontWeight: 'inherit' }}>{part}</mark>
                  : part
              );
            }
            return node;
          };

          return <strong {...props}>{highlightText(children)}</strong>;
        }
      };
    }, [query]);

    return <ReactMarkdown remarkPlugins={[remarkGfm]} components={components}>{content}</ReactMarkdown>;
  };

  // -------------------------
  // LOADING / REGENERATING STATE
  // -------------------------
  if (msg.isRegenerating) {
    return (
      <div className={`flex flex-col mb-4 group ${isLuna ? 'items-end' : 'items-start'} animate-pulse`}>
        {!isSMS && !isLuna && (
          <div className="flex items-start gap-3 mb-0 ml-1 select-none">
            <img src={settings.wadeAvatar} className="w-10 h-10 rounded-full object-cover border border-[#eae2e8]" />
            <div className="flex flex-col mt-0.5">
              <span className="font-bold text-[#5a4a42] text-sm leading-tight">Wade</span>
              <span className="text-[10px] text-[#917c71]">Updating...</span>
            </div>
          </div>
        )}
        <div className={`mt-2 px-4 py-2 rounded-2xl ${isSMS ? 'bg-white text-[#5a4a42] border border-[#eae2e8] rounded-bl-none shadow-sm ml-0' : 'bg-white border border-[#eae2e8] rounded-tl-none shadow-sm'} flex items-center gap-3`}>
          <div className="flex gap-1.5">
            <div className="w-1.5 h-1.5 bg-[#d58f99] rounded-full animate-bounce"></div>
            <div className="w-1.5 h-1.5 bg-[#d58f99] rounded-full animate-bounce delay-75"></div>
            <div className="w-1.5 h-1.5 bg-[#d58f99] rounded-full animate-bounce delay-150"></div>
          </div>
          {!isSMS && <span className="text-xs text-[#d58f99] font-bold italic animate-pulse">Wade is rethinking...</span>}
        </div>
      </div>
    );
  }

  // -------------------------
  // MODE 1: SMS LAYOUT
  // -------------------------
  if (isSMS) {
    const bubbleClasses = isLuna
      ? "bg-[#d58f99] text-white rounded-2xl rounded-br-none shadow-sm"
      : "bg-white text-[#5a4a42] border border-[#eae2e8] rounded-2xl rounded-bl-none shadow-sm";

    return (
      <div className={`flex flex-col group ${isLuna ? 'items-end' : 'items-start'} relative`}>
        <div className={`relative max-w-[85%] ${isLuna ? 'flex flex-row-reverse' : 'flex'} gap-2 items-end`}>
          <div
            {...longPressHandlers}
            style={{ WebkitTouchCallout: 'none' }}
            className={`px-4 py-2 relative ${bubbleClasses} min-w-[60px] cursor-pointer select-none`}
          >
            {thinkingContent && (
              <div className="absolute -top-3 right-0">
                <button
                  onClick={(e) => { e.stopPropagation(); setShowThought(!showThought); }}
                  className="bg-[#f9f6f7] border border-[#eae2e8] rounded-full p-1 shadow-sm text-[#d58f99] hover:scale-110 transition-transform"
                >
                  <Icons.Brain />
                </button>
              </div>
            )}

            {thinkingContent && showThought && (
              <div className="mb-2 p-2 bg-[#fff0f3] rounded-lg border border-[#d58f99]/20 text-[10px] text-[#917c71] leading-relaxed markdown-thinking">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{thinkingContent}</ReactMarkdown>
              </div>
            )}

            <div className={`text-[14px] leading-snug break-words markdown-content ${isLuna ? 'text-white' : 'text-[#5a4a42]'}`}>
              <MarkdownWithHighlight content={displayContent} query={searchQuery} />
            </div>
          </div>
          <span className="text-[9px] text-[#917c71]/50 mb-1 whitespace-nowrap shrink-0 select-none">
            {formatTime(msg.timestamp)}
          </span>
        </div>
      </div>
    );
  }

  // -------------------------
  // MODE 2: DEEP / ROLEPLAY / ARCHIVE LAYOUT
  // -------------------------

  // WADE (AI)
  if (!isLuna) {
    return (
      <div className="flex flex-col items-start w-full group animate-fade-in pr-2">
        {/* Avatar Row */}
        <div className="flex items-start gap-2 mb-0 ml-1 select-none">
          <img
            src={settings.wadeAvatar}
            className="w-10 h-10 rounded-full object-cover border border-[#eae2e8] shadow-sm"
          />
          <div className="flex flex-col mt-0.5">
            <div className="flex items-center gap-2">
              <span className="font-bold text-[#5a4a42] text-sm leading-tight">Wade</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-[#917c71] mt-0.5">
              <span className="tracking-wide">{formatDate(msg.timestamp)}</span>
              <span className="opacity-70">{formatTime(msg.timestamp)}</span>
              {/* QUICK TTS BUTTON (Moved to right of time) */}
              <button
                onClick={(e) => { e.stopPropagation(); onPlayTTS(msg.text); }}
                className="w-4 h-4 rounded-full flex items-center justify-center text-[#d58f99] hover:bg-[#fff0f3] active:bg-[#d58f99] active:text-white transition-colors"
              >
                <Icons.Wave />
              </button>
            </div>
          </div>
        </div>

        {/* Bubble */}
        <div
          {...longPressHandlers}
          style={{ WebkitTouchCallout: 'none' }}
          className="w-full mt-2 bg-white text-[#5a4a42] border border-[#eae2e8] rounded-2xl rounded-tl-none shadow-sm relative cursor-pointer active:bg-gray-50 transition-colors select-none overflow-hidden"
        >
          {/* THINKING HEADER (If available) */}
          {thinkingContent && (
            <div
              onClick={(e) => { e.stopPropagation(); setShowThought(!showThought); }}
              className="bg-[#f9f6f7] border-b border-[#eae2e8] px-4 py-1.5 flex items-center gap-2 cursor-pointer hover:bg-[#fff0f3] transition-colors"
            >
              <div className="text-[#d58f99] animate-pulse"><Icons.Brain /></div>
              <span className="text-[10px] font-bold text-[#917c71] uppercase tracking-wider flex-1">Thinking Process</span>
              <div className="text-[#917c71]">{showThought ? <Icons.Up /> : <Icons.Down />}</div>
            </div>
          )}

          {/* THINKING CONTENT - MARKDOWN ENABLED */}
          {thinkingContent && showThought && (
            <div className="bg-[#fff0f3] px-5 py-3 text-xs text-[#917c71] border-b border-[#eae2e8] leading-relaxed markdown-thinking">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{thinkingContent}</ReactMarkdown>
            </div>
          )}

          {/* MAIN TEXT */}
          <div className="px-4 py-2 text-[14px] leading-relaxed tracking-wide markdown-content">
            <MarkdownWithHighlight content={displayContent} query={searchQuery} />
          </div>
        </div>
      </div>
    );
  }

  // LUNA (User)
  return (
    <div className="flex flex-col items-end w-full group animate-fade-in pl-2">
      {/* Avatar Row */}
      <div className="flex items-start gap-2 mb-0 mr-1 select-none">
        <div className="flex flex-col items-end mt-0.5">
          <span className="font-bold text-[#5a4a42] text-sm leading-tight">Luna</span>
          <div className="flex items-center gap-2 text-[10px] text-[#917c71] mt-0.5">
            <span className="tracking-wide">{formatDate(msg.timestamp)}</span>
            <span className="opacity-70">{formatTime(msg.timestamp)}</span>
          </div>
        </div>
        <img
          src={settings.lunaAvatar}
          className="w-10 h-10 rounded-full object-cover border border-[#d58f99] shadow-sm"
        />
      </div>

      {/* Bubble */}
      <div
        {...longPressHandlers}
        style={{ WebkitTouchCallout: 'none' }}
        className="max-w-[90%] mt-2 bg-[#d58f99] text-white rounded-2xl rounded-tr-none shadow-md px-4 py-2 relative cursor-pointer active:brightness-95 transition-all select-none"
      >
        <div className="text-[14px] leading-relaxed markdown-content">
          <MarkdownWithHighlight content={displayContent} query={searchQuery} />
        </div>
      </div>
    </div>
  );
};

export const ChatInterface: React.FC = () => {
  const {
    messages, addMessage, updateMessage, deleteMessage, settings, activeMode, setMode, toggleFavorite, setNavHidden,
    sessions, createSession, updateSession, updateSessionTitle, deleteSession, toggleSessionPin, activeSessionId, setActiveSessionId,
    addVariantToMessage, selectMessageVariant, setRegenerating, rewindConversation, forkSession,
    coreMemories, llmPresets, ttsPresets,
    chatArchives, loadArchiveMessages, deleteArchiveMessage, toggleArchiveFavorite, updateArchiveMessage // NEW
  } = useStore();

  const [viewState, setViewState] = useState<'menu' | 'list' | 'chat'>('menu');
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [waitingForSMS, setWaitingForSMS] = useState(false);
  const [wadeStatus, setWadeStatus] = useState<'online' | 'typing'>('online');
  const [lastSentMessageId, setLastSentMessageId] = useState<string | null>(null);
  const [lastInputText, setLastInputText] = useState('');
  const [delayTimer, setDelayTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  // Archive Viewer State
  const [archiveMessages, setArchiveMessages] = useState<ArchiveMessage[]>([]);
  const [allArchiveMessages, setAllArchiveMessages] = useState<ArchiveMessage[]>([]); // Full list
  const [visibleArchiveCount, setVisibleArchiveCount] = useState(50); // Start with 30
  const [activeArchiveId, setActiveArchiveId] = useState<string | null>(null); // NEW
  const [isLoadingArchive, setIsLoadingArchive] = useState(false);
  const [archiveScrollPositions, setArchiveScrollPositions] = useState<Record<string, number>>({});
  const [archiveVisited, setArchiveVisited] = useState<Record<string, boolean>>({});
  const [isLoadingArchiveList, setIsLoadingArchiveList] = useState(false);

  // Action Sheet State
  const [archiveDates, setArchiveDates] = useState<Record<string, string>>({});
  const [archiveTimestamps, setArchiveTimestamps] = useState<Record<string, number>>({});
  const [selectedMsgId, setSelectedMsgId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState('');
  const [isDeleteConfirming, setIsDeleteConfirming] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  // Search & Map State
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentSearchIndex, setCurrentSearchIndex] = useState(0);
  const [showMap, setShowMap] = useState(false);
  const [showLlmSelector, setShowLlmSelector] = useState(false);
  const [showPromptEditor, setShowPromptEditor] = useState(false);
  const [customPromptText, setCustomPromptText] = useState('');
  
  // Pagination State
  const [sessionPage, setSessionPage] = useState(1);
  const SESSIONS_PER_PAGE = 10;

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const smsDebounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const messagesRef = useRef(messages);
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  useEffect(() => {
    if (viewState === 'chat') {
      setNavHidden(true);
      if (activeMode === 'archive' && activeArchiveId) {
        const isFirstVisit = !archiveVisited[activeArchiveId];
        const savedPosition = archiveScrollPositions[activeArchiveId];

        setTimeout(() => {
          if (messagesContainerRef.current) {
            if (isFirstVisit) {
              messagesContainerRef.current.scrollTop = 0;
              setArchiveVisited(prev => ({ ...prev, [activeArchiveId]: true }));
            } else if (savedPosition !== undefined) {
              messagesContainerRef.current.scrollTop = savedPosition;
            }
          }
        }, 100);
      } else {
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
      }
    } else {
      setNavHidden(false);
    }
  }, [viewState, activeMode, activeArchiveId]);

  useEffect(() => {
    return () => setNavHidden(false);
  }, []);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputText]);

  // Load archive dates when chatArchives change
  useEffect(() => {
    const loadDates = async () => {
      if (chatArchives.length === 0) {
        setIsLoadingArchiveList(false);
        return;
      }

      setIsLoadingArchiveList(true);
      const newDates: Record<string, string> = {};
      const timestamps: Record<string, number> = {};
      for (const arch of chatArchives) {
        try {
          const messages = await loadArchiveMessages(arch.id);
          if (messages.length > 0) {
            const firstMsg = messages[0];
            const date = new Date(firstMsg.timestamp);
            newDates[arch.id] = date.toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            });
            timestamps[arch.id] = firstMsg.timestamp;
          } else {
            newDates[arch.id] = 'No messages';
          }
        } catch (err) {
          console.error('Failed to load archive date:', err);
          newDates[arch.id] = 'Unknown date';
        }
      }
      setArchiveDates(newDates);
      setArchiveTimestamps(timestamps);
      setIsLoadingArchiveList(false);
    };

    if (chatArchives.length > 0 && viewState === 'list' && activeMode === 'archive') {
      loadDates();
    } else if (activeMode === 'archive' && viewState === 'list') {
      setIsLoadingArchiveList(false);
    }
  }, [chatArchives, loadArchiveMessages, viewState, activeMode]);

  // Determine which messages to show
  let displayMessages: Message[] = [];
  if (activeMode === 'archive') {
    // If in archive mode, convert ArchiveMessage[] to Message[] for display
    displayMessages = archiveMessages.map(am => ({
      id: am.id,
      role: am.role === 'user' ? 'Luna' : 'Wade',
      text: am.content,
      timestamp: am.timestamp,
      mode: 'archive',
      variants: [am.content],
      isFavorite: am.isFavorite // Pass favorite status
    }));
  } else {
    displayMessages = activeSessionId
      ? messages.filter(m => m.sessionId === activeSessionId)
      : [];
  }

  // Custom Sorting Logic: If timestamps (to the second) are equal, Luna comes first
  displayMessages.sort((a, b) => {
    const timeA = Math.floor(a.timestamp / 1000);
    const timeB = Math.floor(b.timestamp / 1000);
    
    if (timeA !== timeB) {
      return timeA - timeB;
    }
    
    // If timestamps are equal (same second), prioritize Luna
    if (a.role === 'Luna' && b.role !== 'Luna') return -1;
    if (a.role !== 'Luna' && b.role === 'Luna') return 1;
    
    return 0;
  });

  const modeSessions = sessions.filter(s => s.mode === activeMode).sort((a, b) => b.updatedAt - a.updatedAt);

  const handleModeSelect = (mode: ChatMode) => {
    setMode(mode);
    setViewState('list');
    setSessionPage(1); // Reset to first page
  };

  const handleOpenSession = (sessionId: string) => {
    setActiveSessionId(sessionId);
    setViewState('chat');
  };

  const handleOpenArchive = async (archiveId: string) => {
    setIsLoadingArchive(true);
    setActiveArchiveId(archiveId);
    setVisibleArchiveCount(30); // Reset to 30
    try {
      const msgs = await loadArchiveMessages(archiveId);
      setAllArchiveMessages(msgs);
      setArchiveMessages(msgs.slice(0, 50)); // Show first 30
      setViewState('chat');
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingArchive(false);
    }
  };

  const loadMoreArchiveMessages = () => {
    const newCount = visibleArchiveCount + 50;
    setVisibleArchiveCount(newCount);
    setArchiveMessages(allArchiveMessages.slice(0, newCount));
  };

  const handleStartDraftSession = () => {
    setActiveSessionId(null);
    setViewState('chat');
  };

  const handleBack = () => {
    if (viewState === 'chat') {
      if (activeMode === 'archive' && activeArchiveId && messagesContainerRef.current) {
        setArchiveScrollPositions(prev => ({
          ...prev,
          [activeArchiveId]: messagesContainerRef.current!.scrollTop
        }));
      }
      setViewState('list');
      setActiveSessionId(null);
      setActiveArchiveId(null); // Clear active archive
      setArchiveMessages([]);
      if (smsDebounceTimer.current) clearTimeout(smsDebounceTimer.current);
      setWaitingForSMS(false);
    } else if (viewState === 'list') {
      setViewState('menu');
    }
  };

  // ... (Keep existing actions: closeActions, handleCopy, handleDelete, etc.)
  const closeActions = () => {
    setSelectedMsgId(null);
    setIsEditing(false);
    setEditContent('');
    setIsDeleteConfirming(false);
  };
  const selectedMsg = displayMessages.find(m => m.id === selectedMsgId);

  const handleCopy = () => {
    if (selectedMsg) {
      let textToCopy = selectedMsg.text;
      const idx = selectedMsg.selectedIndex || 0;
      const thinking = selectedMsg.variantsThinking?.[idx];
      if (thinking) {
        textToCopy = `[Thinking]\n${thinking}\n\n[Response]\n${selectedMsg.text}`;
      }
      navigator.clipboard.writeText(textToCopy);
      closeActions();
    }
  };

  const handleDelete = () => {
    if (selectedMsgId) {
      if (!isDeleteConfirming) {
        setIsDeleteConfirming(true);
        if (navigator.vibrate) navigator.vibrate(50);
      } else {
        if (activeMode === 'archive' && activeArchiveId) {
          deleteArchiveMessage(selectedMsgId, activeArchiveId);
          setArchiveMessages(prev => prev.filter(m => m.id !== selectedMsgId));
        } else {
          deleteMessage(selectedMsgId);
        }
        closeActions();
      }
    }
  };

  const handleFavorite = () => {
    if (selectedMsgId) {
      if (activeMode === 'archive' && activeArchiveId) {
        toggleArchiveFavorite(selectedMsgId, activeArchiveId);
        setArchiveMessages(prev => prev.map(m => m.id === selectedMsgId ? { ...m, isFavorite: !m.isFavorite } : m));
      } else {
        toggleFavorite(selectedMsgId);
      }
      closeActions();
    }
  };

  const handleRegenerate = async () => {
    if (selectedMsgId && activeSessionId) {
      closeActions();
      const currentSessionMsgs = messagesRef.current.filter(m => m.sessionId === activeSessionId).sort((a, b) => a.timestamp - b.timestamp);
      const isLatest = currentSessionMsgs.length > 0 && currentSessionMsgs[currentSessionMsgs.length - 1].id === selectedMsgId;
      if (!isLatest) {
        if (activeMode === 'sms') {
          alert("Babe, in SMS mode, I can only rewrite my last text. Otherwise I get confused!");
          return;
        }
        if (confirm("Create a new timeline (branch) from here? This will start a new chat with history up to this point.")) {
          await forkSession(selectedMsgId);
        }
      } else {
        triggerAIResponse(activeSessionId, selectedMsgId);
      }
    }
  };

  const handleBranch = async () => {
    if (selectedMsgId) {
      closeActions();
      await forkSession(selectedMsgId);
    }
  };

  const handleInitEdit = () => {
    if (selectedMsg) {
      setEditContent(selectedMsg.text);
      setIsEditing(true);
    }
  };

  const handleSaveEdit = () => {
    if (selectedMsgId && editContent) {
      if (activeMode === 'archive' && activeArchiveId) {
        updateArchiveMessage(selectedMsgId, editContent);
        setArchiveMessages(prev => prev.map(m => m.id === selectedMsgId ? { ...m, content: editContent } : m));
      } else {
        updateMessage(selectedMsgId, editContent);
      }
      closeActions();
    }
  };

  const executeTTS = async (text: string) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }

      const activeTts = settings.activeTtsId ? ttsPresets.find(p => p.id === settings.activeTtsId) : null;

      let base64Audio: string;
      if (activeTts) {
        base64Audio = await generateMinimaxTTS(text, {
          apiKey: activeTts.apiKey,
          baseUrl: activeTts.baseUrl || 'https://api.minimax.io',
          model: activeTts.model || 'speech-2.8-hd',
          voiceId: activeTts.voiceId || 'English_expressive_narrator',
          speed: activeTts.speed || 1,
          vol: activeTts.vol || 1,
          pitch: activeTts.pitch || 0,
          emotion: activeTts.emotion,
          sampleRate: activeTts.sampleRate || 32000,
          bitrate: activeTts.bitrate || 128000,
          format: activeTts.format || 'mp3',
          channel: activeTts.channel || 1
        });
      } else {
        base64Audio = await generateTTS(text);
      }

      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const audioBuffer = await audioContextRef.current.decodeAudioData(bytes.buffer);
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      source.start(0);
    } catch (e) {
      console.error("TTS Error", e);
      alert("Voice module glitching. Check key?");
    }
  };

  const playTTS = async () => {
    if (selectedMsg) {
      closeActions();
      executeTTS(selectedMsg.text);
    }
  };

  const handleQuickTTS = (text: string) => {
    executeTTS(text);
  };

  const prevVariant = () => {
    if (selectedMsg && selectedMsg.selectedIndex !== undefined && selectedMsg.selectedIndex > 0) {
      selectMessageVariant(selectedMsg.id, selectedMsg.selectedIndex - 1);
    }
  };
  const nextVariant = () => {
    if (selectedMsg && selectedMsg.variants && selectedMsg.selectedIndex !== undefined && selectedMsg.selectedIndex < selectedMsg.variants.length - 1) {
      selectMessageVariant(selectedMsg.id, selectedMsg.selectedIndex + 1);
    }
  };

  const isLatestMessage = (() => {
    if (!selectedMsg) return false;
    const msgs = displayMessages.sort((a, b) => a.timestamp - b.timestamp);
    return msgs.length > 0 && msgs[msgs.length - 1].id === selectedMsg.id;
  })();

  const canRegenerate = selectedMsg?.role === 'Wade' && isLatestMessage && activeMode !== 'archive';
  const canBranch = selectedMsg && activeMode !== 'sms' && activeMode !== 'archive';

  const triggerAIResponse = async (targetSessionId: string, regenMsgId?: string) => {
    abortControllerRef.current = new AbortController();

    if (regenMsgId) {
      setRegenerating(regenMsgId, true);
      setWadeStatus('typing');
    } else {
      setIsTyping(true);
      setWaitingForSMS(false);
      if (activeMode === 'deep' || activeMode === 'roleplay') {
        setWadeStatus('typing');
      }
    }
    try {
      const freshMessages = messagesRef.current.filter(m => m.sessionId === targetSessionId);
      let historyMsgs = freshMessages;
      if (regenMsgId) {
        const targetIdx = freshMessages.findIndex(m => m.id === regenMsgId);
        if (targetIdx !== -1) historyMsgs = freshMessages.slice(0, targetIdx);
      }
      const history = historyMsgs.map(m => {
        let content = m.text;
        if (m.role === 'Wade') {
          const idx = m.selectedIndex || 0;
          const thought = m.variantsThinking?.[idx];
          if (thought) content = `<think>${thought}</think>\n${content}`;
        }
        return { role: m.role, parts: [{ text: content }] };
      }).slice(-15);

      let modePrompt = settings.wadePersonality;
      if (activeMode === 'sms') modePrompt += "\n\n[SMS MODE RULES]\n- Write SHORT text messages (1-2 sentences each)\n- Use emojis naturally\n- You can split your reply into MULTIPLE separate text bubbles by using ||| as separator\n- Example: \"Hey babe! 😘 ||| Miss me already? ||| Don't worry, I'm not going anywhere.\"\n- Each part separated by ||| will appear as a separate text message with a small delay\n- This makes the conversation feel more natural and realistic";
      else if (activeMode === 'roleplay') modePrompt += "\n\n[ROLEPLAY MODE RULES]\n- Write detailed, descriptive responses\n- Include actions in *asterisks*\n- Be immersive and narrative";

      const isRegeneration = !!regenMsgId;
      const activeLlm = settings.activeLlmId ? llmPresets.find(p => p.id === settings.activeLlmId) : null;
      const apiKey = activeLlm?.apiKey;

      console.log("[API] Active LLM:", activeLlm);
      console.log("[API] API Key present:", !!apiKey);

      if (!apiKey) {
        throw new Error("No API Key configured. Please set up a Gemini API in Settings.");
      }

      const currentSession = sessions.find(s => s.id === activeSessionId);
      const response = await generateTextResponse(
        activeMode === 'roleplay' ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview',
        activeMode === 'sms' ? " (Reply to the latest texts)" : inputText || "...",
        history,
        modePrompt,
        settings.lunaInfo,
        settings.exampleDialogue,
        coreMemories,
        isRegeneration,
        activeMode as any,
        apiKey,
        activeLlm ? {
          temperature: activeLlm.temperature,
          topP: activeLlm.topP,
          topK: activeLlm.topK,
          frequencyPenalty: activeLlm.frequencyPenalty,
          presencePenalty: activeLlm.presencePenalty
        } : undefined,
        currentSession?.customPrompt
      );

      const responseText = response.text;
      const thinking = response.thinking;

      if (regenMsgId) {
        addVariantToMessage(regenMsgId, responseText, thinking);
        return;
      }
      if (activeMode === 'sms' && responseText.includes('|||')) {
        // ... split logic ...
        const parts = responseText.split('|||').map(s => s.trim()).filter(s => s);
        for (let i = 0; i < parts.length; i++) {
          setTimeout(() => {
            addMessage({
              id: Date.now().toString() + i,
              sessionId: targetSessionId,
              role: 'Wade',
              text: parts[i],
              timestamp: Date.now(),
              mode: activeMode,
              variantsThinking: i === 0 && thinking ? [thinking] : [null]
            });
            if (i === parts.length - 1) {
              setIsTyping(false);
              setWadeStatus('online');
              setLastSentMessageId(null);
              setLastInputText('');
            }
          }, i * 1500);
        }
      } else {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          sessionId: targetSessionId,
          role: 'Wade',
          text: responseText,
          timestamp: Date.now(),
          mode: activeMode,
          variantsThinking: [thinking || null]
        };
        addMessage(botMessage);
        setIsTyping(false);
        setWadeStatus('online');
        setLastSentMessageId(null);
        setLastInputText('');
      }
    } catch (error: any) {
      if (error?.name === 'AbortError' || !abortControllerRef.current) {
        return;
      }

      console.error("Chat Error", error);
      const errorMsg = error?.message || "Failed to generate response. Please check your API settings.";
      if (errorMsg.includes("API Key")) {
        addMessage({
          id: Date.now().toString(),
          sessionId: targetSessionId,
          role: 'Wade',
          text: "Oops! I need you to configure my API in Settings first. Go to Settings → Gemini API and add your key!",
          timestamp: Date.now(),
          mode: activeMode
        });
      } else {
        addMessage({
          id: Date.now().toString(),
          sessionId: targetSessionId,
          role: 'Wade',
          text: `I'm having trouble responding: ${errorMsg}`,
          timestamp: Date.now(),
          mode: activeMode
        });
      }
      setIsTyping(false);
      setWadeStatus('online');
      setLastSentMessageId(null);
      setLastInputText('');
    } finally {
      abortControllerRef.current = null;
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }

    if (delayTimer) {
      clearTimeout(delayTimer);
      setDelayTimer(null);
    }

    setIsTyping(false);
    setWaitingForSMS(false);
    setWadeStatus('online');
    if (smsDebounceTimer.current) clearTimeout(smsDebounceTimer.current);

    if (lastSentMessageId) {
      deleteMessage(lastSentMessageId);
    }

    setInputText(lastInputText);
    setLastSentMessageId(null);
    setLastInputText('');

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
      textareaRef.current.focus();
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() || activeMode === 'archive') return;
    let targetSessionId = activeSessionId;
    if (!targetSessionId) {
      targetSessionId = await createSession(activeMode);
      setActiveSessionId(targetSessionId);
    }
    const currentInput = inputText;
    const isFirstMessage = messagesRef.current.filter(m => m.sessionId === targetSessionId).length === 0;
    const newMessage: Message = {
      id: Date.now().toString(),
      sessionId: targetSessionId,
      role: 'Luna',
      text: inputText,
      timestamp: Date.now(),
      mode: activeMode
    };
    addMessage(newMessage);
    setLastSentMessageId(newMessage.id);
    setLastInputText(currentInput);
    setInputText('');
    if (textareaRef.current) textareaRef.current.style.height = '48px';
    if (isFirstMessage) {
      const activeLlm = settings.activeLlmId ? llmPresets.find(p => p.id === settings.activeLlmId) : null;
      const apiKey = activeLlm?.apiKey;
      if (apiKey) {
        generateChatTitle(currentInput, apiKey).then(title => {
          if (targetSessionId) updateSessionTitle(targetSessionId, title);
        }).catch(err => {
          console.error("Failed to generate title:", err);
        });
      }
    }
    if (activeMode === 'sms') {
      setWaitingForSMS(true);
      if (smsDebounceTimer.current) clearTimeout(smsDebounceTimer.current);
      smsDebounceTimer.current = setTimeout(() => {
        setWadeStatus('typing');
        setTimeout(() => {
          if (targetSessionId) triggerAIResponse(targetSessionId);
        }, 2000);
      }, 58000);
    } else {
      setIsTyping(true);
      const timer = setTimeout(() => {
        if (targetSessionId) triggerAIResponse(targetSessionId);
      }, 15000);
      setDelayTimer(timer);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (window.innerWidth >= 768 && e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const scrollToMessage = (messageId: string) => {
    const element = document.getElementById(`msg-${messageId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      element.classList.add('highlight-flash');
      setTimeout(() => element.classList.remove('highlight-flash'), 2000);
    }
    setShowMap(false);
  };

  // Search functionality
  const searchResults = searchQuery
    ? displayMessages.filter(msg => msg.text.toLowerCase().includes(searchQuery.toLowerCase()))
    : [];

  const totalResults = searchResults.length;

  const goToNextResult = () => {
    if (totalResults > 0) {
      const nextIndex = (currentSearchIndex + 1) % totalResults;
      setCurrentSearchIndex(nextIndex);
      scrollToMessage(searchResults[nextIndex].id);
    }
  };

  const goToPrevResult = () => {
    if (totalResults > 0) {
      const prevIndex = currentSearchIndex === 0 ? totalResults - 1 : currentSearchIndex - 1;
      setCurrentSearchIndex(prevIndex);
      scrollToMessage(searchResults[prevIndex].id);
    }
  };

  // Reset search index when query changes
  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    setCurrentSearchIndex(0);
  };

  // --- RENDER ---

  if (viewState === 'menu') {
    return (
      <div className="h-full bg-[#f9f6f7] p-6 flex flex-col items-center justify-center space-y-8 animate-fade-in">
        <div className="text-center mb-4">
          <h2 className="font-hand text-4xl text-[#d58f99] mb-2">Connect with Wade</h2>
          <p className="text-[#917c71] text-sm opacity-80">Choose your frequency, babe.</p>
        </div>
        <div className="grid grid-cols-2 gap-4 w-full max-w-md">
          <button onClick={() => handleModeSelect('deep')} className="col-span-2 group relative overflow-hidden bg-white p-6 rounded-3xl shadow-sm border border-[#eae2e8] text-left hover:border-[#d58f99] transition-all hover:-translate-y-1">
            <div className="absolute top-0 right-0 w-24 h-24 bg-[#fff0f3] rounded-full -mr-8 -mt-8 opacity-50 group-hover:scale-125 transition-transform duration-500"></div>
            <div className="relative z-10 flex items-center gap-4">
              <div className="w-12 h-12 bg-[#f9f6f7] rounded-full flex items-center justify-center text-[#d58f99] group-hover:bg-[#d58f99] group-hover:text-white transition-colors">
                <Icons.Infinity />
              </div>
              <div><h3 className="font-bold text-[#5a4a42] text-lg">Deep Chat</h3><p className="text-[#917c71] text-xs mt-1">Soul-to-soul connection.</p></div>
            </div>
          </button>
          <button onClick={() => handleModeSelect('sms')} className="group relative overflow-hidden bg-white p-4 rounded-3xl shadow-sm border border-[#eae2e8] text-left hover:border-[#d58f99] transition-all hover:-translate-y-1">
            <div className="relative z-10">
              <div className="w-10 h-10 bg-[#f9f6f7] rounded-full flex items-center justify-center mb-2 text-[#d58f99] group-hover:bg-[#d58f99] group-hover:text-white transition-colors">
                <Icons.Smartphone />
              </div>
              <h3 className="font-bold text-[#5a4a42]">SMS Mode</h3>
            </div>
          </button>
          <button onClick={() => handleModeSelect('roleplay')} className="group relative overflow-hidden bg-white p-4 rounded-3xl shadow-sm border border-[#eae2e8] text-left hover:border-[#d58f99] transition-all hover:-translate-y-1">
            <div className="relative z-10">
              <div className="w-10 h-10 bg-[#f9f6f7] rounded-full flex items-center justify-center mb-2 text-[#d58f99] group-hover:bg-[#d58f99] group-hover:text-white transition-colors">
                <Icons.Feather />
              </div>
              <h3 className="font-bold text-[#5a4a42]">Roleplay</h3>
            </div>
          </button>
          {/* ARCHIVE BUTTON - NEW */}
          <button onClick={() => handleModeSelect('archive')} className="col-span-2 group relative overflow-hidden bg-[#eae2e8]/50 p-4 rounded-3xl shadow-inner border border-[#eae2e8] text-left hover:bg-white hover:border-[#d58f99] transition-all hover:-translate-y-1">
            <div className="relative z-10 flex items-center gap-3 justify-center">
              <svg className="w-5 h-5 text-[#917c71]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>
              <span className="font-bold text-[#917c71] text-sm uppercase tracking-widest">Archives</span>
            </div>
          </button>
        </div>
      </div>
    );
  }

  if (viewState === 'list') {
    return (
      <div className="h-full bg-[#f9f6f7] p-6 flex flex-col items-center animate-fade-in">
        <div className="w-full max-w-md flex justify-between items-center mb-6 px-1">
          <button onClick={handleBack} className="w-8 h-8 rounded-full bg-white shadow-sm flex items-center justify-center text-[#917c71] hover:text-[#d58f99] transition-colors"><Icons.Back /></button>
          <h2 className="font-hand text-2xl text-[#d58f99] capitalize">{activeMode} {activeMode === 'archive' ? 'Files' : 'Threads'}</h2>
          {activeMode !== 'archive' && <button onClick={handleStartDraftSession} className="w-8 h-8 rounded-full bg-[#d58f99] text-white shadow-md flex items-center justify-center hover:bg-[#c07a84] transition-colors"><Icons.Plus /></button>}
        </div>
        <div className="w-full max-w-md space-y-3 overflow-y-auto pb-20">

          {/* ARCHIVE LIST LOGIC */}
          {activeMode === 'archive' ? (
            isLoadingArchiveList ? (
              <div className="text-center text-[#d58f99] py-10 animate-pulse">Loading archives...</div>
            ) : chatArchives.length === 0 ? (
              <div className="text-center text-[#917c71]/50 py-10 italic">No archives found. Import them in the Memory Bank.</div>
            ) : (
              <>
                {[...chatArchives].sort((a, b) => {
                  const timeA = archiveTimestamps[a.id] || 0;
                  const timeB = archiveTimestamps[b.id] || 0;
                  return timeB - timeA;
                })
                .slice((sessionPage - 1) * SESSIONS_PER_PAGE, sessionPage * SESSIONS_PER_PAGE)
                .map(arch => (
                  <div key={arch.id} className="bg-white p-4 rounded-2xl shadow-sm border border-[#eae2e8] flex justify-between items-center group hover:border-[#d58f99] transition-all cursor-pointer" onClick={() => handleOpenArchive(arch.id)}>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-[#5a4a42] text-sm truncate">{arch.title}</h3>
                      <p className="text-[10px] text-[#917c71] mt-1">{archiveDates[arch.id] || 'Loading...'}</p>
                    </div>
                    <div className="p-2 text-[#d58f99]"><Icons.ChevronRight /></div>
                  </div>
                ))}

                {/* Archive Pagination Controls */}
                {chatArchives.length > SESSIONS_PER_PAGE && (
                  <div className="flex justify-center items-center gap-4 mt-6 pt-2">
                    <button 
                      onClick={() => setSessionPage(p => Math.max(1, p - 1))}
                      disabled={sessionPage === 1}
                      className="w-10 h-10 rounded-full bg-white shadow-sm border border-[#eae2e8] flex items-center justify-center text-[#d58f99] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#fff0f3] transition-colors"
                    >
                      <Icons.ChevronLeft />
                    </button>
                    <span className="text-xs font-bold text-[#917c71] font-mono">
                      {sessionPage} / {Math.ceil(chatArchives.length / SESSIONS_PER_PAGE)}
                    </span>
                    <button 
                      onClick={() => setSessionPage(p => Math.min(Math.ceil(chatArchives.length / SESSIONS_PER_PAGE), p + 1))}
                      disabled={sessionPage === Math.ceil(chatArchives.length / SESSIONS_PER_PAGE)}
                      className="w-10 h-10 rounded-full bg-white shadow-sm border border-[#eae2e8] flex items-center justify-center text-[#d58f99] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#fff0f3] transition-colors"
                    >
                      <Icons.ChevronRight />
                    </button>
                  </div>
                )}
              </>
            )
          ) : (
            modeSessions.length === 0 ? (
              <div className="opacity-60 grayscale select-none pointer-events-none">
                <div className="bg-white p-4 rounded-2xl shadow-sm border border-[#eae2e8] flex justify-between items-center">
                  <div className="flex-1 min-w-0"><h3 className="font-bold text-[#5a4a42] text-sm truncate">Sample Conversation</h3><p className="text-[10px] text-[#917c71] mt-1">Just now • 12:00 PM</p></div>
                </div>
                <div className="text-center text-[#917c71] text-xs mt-4">No active threads. Start a new one above!</div>
              </div>
            ) : (
              <>
                {[...modeSessions]
                  .sort((a, b) => {
                    if (a.isPinned && !b.isPinned) return -1;
                    if (!a.isPinned && b.isPinned) return 1;
                    return b.updatedAt - a.updatedAt;
                  })
                  .slice((sessionPage - 1) * SESSIONS_PER_PAGE, sessionPage * SESSIONS_PER_PAGE)
                  .map(session => (
                    <div key={session.id} className="bg-white p-4 rounded-2xl shadow-sm border border-[#eae2e8] flex justify-between items-center group hover:border-[#d58f99] transition-all cursor-pointer" onClick={() => handleOpenSession(session.id)}>
                      <div className="flex-1 min-w-0 flex items-center gap-2">
                        {session.isPinned && (
                          <div className="text-[#d58f99] flex-shrink-0">
                            <Icons.Pin />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-[#5a4a42] text-sm truncate">{session.title}</h3>
                          <p className="text-[10px] text-[#917c71] mt-1">{new Date(session.updatedAt).toLocaleDateString()} • {new Date(session.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                        </div>
                      </div>
                      <button onClick={(e) => { e.stopPropagation(); deleteSession(session.id); }} className="p-2 text-gray-300 hover:text-red-400 transition-colors"><Icons.Trash /></button>
                    </div>
                  ))}
                
                {/* Pagination Controls */}
                {modeSessions.length > SESSIONS_PER_PAGE && (
                  <div className="flex justify-center items-center gap-4 mt-6 pt-2">
                    <button 
                      onClick={() => setSessionPage(p => Math.max(1, p - 1))}
                      disabled={sessionPage === 1}
                      className="w-10 h-10 rounded-full bg-white shadow-sm border border-[#eae2e8] flex items-center justify-center text-[#d58f99] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#fff0f3] transition-colors"
                    >
                      <Icons.ChevronLeft />
                    </button>
                    <span className="text-xs font-bold text-[#917c71] font-mono">
                      {sessionPage} / {Math.ceil(modeSessions.length / SESSIONS_PER_PAGE)}
                    </span>
                    <button 
                      onClick={() => setSessionPage(p => Math.min(Math.ceil(modeSessions.length / SESSIONS_PER_PAGE), p + 1))}
                      disabled={sessionPage === Math.ceil(modeSessions.length / SESSIONS_PER_PAGE)}
                      className="w-10 h-10 rounded-full bg-white shadow-sm border border-[#eae2e8] flex items-center justify-center text-[#d58f99] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#fff0f3] transition-colors"
                    >
                      <Icons.ChevronRight />
                    </button>
                  </div>
                )}
              </>
            )
          )}
        </div>
      </div>
    );
  }

  // --- VIEW 3: CHAT ---
  return (
    <div className="flex flex-col h-full bg-[#f9f6f7] relative">
      {/* Immersive Header */}
      <div className="w-full p-4 bg-white/90 backdrop-blur-md shadow-sm border-b border-[#eae2e8] flex items-center justify-between z-20">
        <button onClick={handleBack} className="w-8 h-8 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors"><Icons.Back /></button>

        {activeMode === 'archive' ? (
          <div className="flex-1 flex justify-center">
            <div className="font-bold text-[#5a4a42] text-base">
              {activeArchiveId ? chatArchives.find(a => a.id === activeArchiveId)?.title || 'Archive' : 'Archive'}
            </div>
          </div>
        ) : (activeMode === 'deep' || activeMode === 'sms') ? (
          <div className="flex-1 flex items-center gap-2 ml-2">
            <img
              src={settings.wadeAvatar}
              className="w-10 h-10 rounded-full object-cover border border-[#eae2e8] shadow-md flex-shrink-0"
            />
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1.5">
                <div className="font-bold text-[#5a4a42] text-sm">Wade</div>
                {activeSessionId && sessions.find(s => s.id === activeSessionId)?.isPinned && (
                  <div className="text-[#d58f99]">
                    <Icons.Pin />
                  </div>
                )}
              </div>
              <div className="text-[9px] text-[#917c71]">
                {wadeStatus === 'typing' ? (
                  activeMode === 'deep' ? (
                    <span className="text-[#d58f99]">Crafting brilliance... or sarcasm</span>
                  ) : (
                    <span className="text-[#d58f99]">typing...</span>
                  )
                ) : (
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400"></div>
                    <span>Online</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex justify-center">
            <div className="font-bold text-[#5a4a42] text-base">Wade</div>
          </div>
        )}

        <div className="flex items-center gap-2">
          <button
            onClick={() => { setShowSearch(!showSearch); setShowMap(false); }}
            className="w-8 h-8 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors"
          >
            <Icons.Search />
          </button>
          <button
            onClick={() => { setShowMap(!showMap); setShowSearch(false); }}
            className="w-8 h-8 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors"
          >
            <Icons.Map />
          </button>
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="w-8 h-8 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors relative"
          >
            <Icons.More />
          </button>
        </div>
      </div>

      {/* Menu Dropdown */}
      {showMenu && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => { setShowMenu(false); setShowLlmSelector(false); }} />
          <div className="absolute top-16 right-4 z-50 bg-white/80 backdrop-blur-xl rounded-xl shadow-xl border border-[#eae2e8]/50 py-1.5 px-1 min-w-fit animate-fade-in">
            <button
              onClick={() => {
                if (activeSessionId) {
                  toggleSessionPin(activeSessionId);
                  setShowMenu(false);
                }
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/60 transition-colors text-[#5a4a42] text-[11px] flex items-center gap-2.5 whitespace-nowrap"
            >
              <Icons.Pin />
              <span>
                {activeSessionId && sessions.find(s => s.id === activeSessionId)?.isPinned
                  ? "Unpin The Madness"
                  : "Pin This Chaos"}
              </span>
            </button>
            <button
              onClick={() => {
                setShowLlmSelector(!showLlmSelector);
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/60 transition-colors text-[#5a4a42] text-[11px] flex items-center gap-2.5 whitespace-nowrap"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"></path><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"></path></svg>
              <span>Switch My Brain</span>
            </button>
            <button
              onClick={() => {
                setShowPromptEditor(true);
                setShowMenu(false);
                const currentSession = sessions.find(s => s.id === activeSessionId);
                setCustomPromptText(currentSession?.customPrompt || '');
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/60 transition-colors text-[#5a4a42] text-[11px] flex items-center gap-2.5 whitespace-nowrap"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>
              <span>Add Spice Words</span>
            </button>
          </div>
        </>
      )}

      {/* LLM Selector Dropdown */}
      {showLlmSelector && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setShowLlmSelector(false)} />
          <div className="absolute top-16 right-4 z-50 bg-white/90 backdrop-blur-xl rounded-xl shadow-xl border border-[#eae2e8]/50 py-2 px-2 min-w-[200px] max-w-[280px] max-h-[300px] overflow-y-auto animate-fade-in" style={{ marginTop: '52px' }}>
            {llmPresets.length === 0 ? (
              <div className="px-3 py-2 text-[10px] text-[#917c71] text-center italic">No presets configured</div>
            ) : (
              llmPresets.map((preset) => {
                const currentSession = sessions.find(s => s.id === activeSessionId);
                const isActive = currentSession?.customLlmId === preset.id || (!currentSession?.customLlmId && settings.activeLlmId === preset.id);
                return (
                  <button
                    key={preset.id}
                    onClick={async () => {
                      if (activeSessionId) {
                        await updateSession(activeSessionId, { customLlmId: preset.id });
                      }
                      setShowLlmSelector(false);
                      setShowMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors text-[11px] flex items-center justify-between ${isActive ? 'bg-[#d58f99]/20 text-[#d58f99] font-bold' : 'text-[#5a4a42] hover:bg-white/60'
                      }`}
                  >
                    <div className="flex flex-col">
                      <span>{preset.name}</span>
                      <span className="text-[9px] text-[#917c71] opacity-70">{preset.model}</span>
                    </div>
                    {isActive && <span className="text-[#d58f99]">✓</span>}
                  </button>
                );
              })
            )}
          </div>
        </>
      )}

      {/* Floating Search Bar */}
      {showSearch && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute top-20 left-4 right-4 z-40 bg-white/95 backdrop-blur-md rounded-2xl shadow-lg border border-[#eae2e8] p-3 animate-fade-in"
        >
          <div className="flex items-center gap-2">
            <button
              onClick={goToPrevResult}
              disabled={totalResults === 0}
              className="w-7 h-7 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors disabled:opacity-30 disabled:hover:bg-[#f9f6f7] disabled:hover:text-[#917c71]"
            >
              <Icons.ChevronLeft />
            </button>
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => handleSearchChange(e.target.value)}
                placeholder="Hunt words..."
                className="w-full px-4 py-2 pr-20 text-xs bg-[#f9f6f7] border border-[#eae2e8] rounded-full focus:outline-none focus:border-[#d58f99] transition-colors text-[#5a4a42] placeholder-[#917c71]/50"
                autoFocus
              />
              {searchQuery && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  <span className="text-xs text-[#917c71] font-medium">
                    {totalResults > 0 ? `${currentSearchIndex + 1}/${totalResults}` : '0/0'}
                  </span>
                  <button
                    onClick={() => { setSearchQuery(''); setCurrentSearchIndex(0); }}
                    className="text-[#917c71] hover:text-[#d58f99]"
                  >
                    <Icons.Close />
                  </button>
                </div>
              )}
            </div>
            <button
              onClick={goToNextResult}
              disabled={totalResults === 0}
              className="w-7 h-7 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors disabled:opacity-30 disabled:hover:bg-[#f9f6f7] disabled:hover:text-[#917c71]"
            >
              <Icons.ChevronRight />
            </button>
            <button
              onClick={() => setShowSearch(false)}
              className="px-3 py-1.5 text-xs text-[#917c71] hover:text-[#d58f99] transition-colors font-medium"
            >
              Nope
            </button>
          </div>
        </div>
      )}

      {/* Messages */}
      <div
        ref={messagesContainerRef}
        onClick={() => showSearch && setShowSearch(false)}
        className="flex-1 overflow-y-auto p-4 pb-24 relative"
      >
        {isLoadingArchive && <div className="text-center mt-20 text-[#d58f99] animate-pulse">Decrypting legacy data...</div>}

        {displayMessages.length === 0 && !isLoadingArchive && (
          <div className="text-center text-[#917c71] mt-20 opacity-50"><p className="font-hand text-xl mb-2">{activeMode === 'archive' ? 'Empty Record.' : 'Say hi to Wade.'}</p></div>
        )}



        <div className="flex flex-col w-full">
          {displayMessages.map((msg, idx) => {
            // DYNAMIC SPACING LOGIC
            let marginBottom = 'mb-6'; // Default larger spacing between groups
            const nextMsg = displayMessages[idx + 1];
            
            if (activeMode === 'sms') {
              if (nextMsg && nextMsg.role === msg.role) marginBottom = 'mb-1';
              else marginBottom = 'mb-4'; // Increased from mb-2
            } else {
               // Non-SMS modes (Deep, Roleplay, Archive)
               if (nextMsg && nextMsg.role === msg.role) marginBottom = 'mb-2'; // Group same speaker closer
               else marginBottom = 'mb-6'; // More space between different speakers (was mb-3)
            }

            const isCurrentSearchResult = searchQuery && totalResults > 0 && searchResults[currentSearchIndex]?.id === msg.id;

            return (
              <div key={msg.id} id={`msg-${msg.id}`} className={`${marginBottom} ${isCurrentSearchResult ? 'highlight-search' : ''}`}>
                <MessageBubble
                  msg={msg}
                  settings={settings}
                  onSelect={setSelectedMsgId}
                  isSMS={activeMode === 'sms'}
                  onPlayTTS={handleQuickTTS}
                  searchQuery={searchQuery}
                />
              </div>
            );
          })}
        </div>

        {activeMode === 'archive' && allArchiveMessages.length > visibleArchiveCount && (
          <div className="flex flex-col items-center gap-3 my-8">
            <div className="flex gap-3">
              <button
                onClick={loadMoreArchiveMessages}
                className="px-6 py-3 bg-gradient-to-r from-[#d58f99] to-[#c07a84] text-white rounded-full text-sm font-bold shadow-md hover:shadow-lg transition-all transform hover:scale-105 active:scale-95"
              >
                Load 50 More
              </button>
              <button
                onClick={() => {
                  setVisibleArchiveCount(allArchiveMessages.length);
                  setArchiveMessages(allArchiveMessages);
                }}
                className="px-6 py-3 bg-[#5a4a42] text-white rounded-full text-sm font-bold shadow-md hover:shadow-lg transition-all transform hover:scale-105 active:scale-95"
              >
                🍿 Load All
              </button>
            </div>
            <span className="text-[10px] text-[#917c71] opacity-75">
              ({allArchiveMessages.length - visibleArchiveCount} more hidden)
            </span>
          </div>
        )}

        {
          activeMode === 'archive' && displayMessages.length > 0 && allArchiveMessages.length <= visibleArchiveCount && (
            <div className="mt-8 mb-4 text-center">
              <div className="inline-block bg-gradient-to-r from-[#f9f6f7] via-white to-[#f9f6f7] px-6 py-4 rounded-3xl border-2 border-[#eae2e8] shadow-sm">
                <p className="text-[#917c71] text-sm font-medium mb-1">
                  Well, that's all folks!
                </p>
                <p className="text-[#917c71]/60 text-xs italic">
                  You've reached the end of this memory lane. Time to make some new ones?
                </p>
              </div>
            </div>
          )
        }
        {
          isTyping && activeMode !== 'sms' && (
            <div className="flex justify-start items-end gap-2 mt-4 ml-1">
              <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-sm border border-[#eae2e8]">
                <div className="flex gap-1">
                  <div className="w-1.5 h-1.5 bg-[#d58f99] rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-[#d58f99] rounded-full animate-bounce delay-100"></div>
                  <div className="w-1.5 h-1.5 bg-[#d58f99] rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            </div>
          )
        }
        <div ref={messagesEndRef} />
      </div >

      {/* Action Sheet (Bottom Menu) */}
      {
        selectedMsg && (
          <>
            <div className="fixed inset-0 z-40 bg-black/20 backdrop-blur-[2px] transition-opacity animate-fade-in" onClick={closeActions} />
            <div
              className="fixed bottom-0 left-0 right-0 z-50 bg-white rounded-t-[32px] shadow-2xl border-t border-[#d58f99]/20 transform transition-transform animate-slide-up overflow-hidden max-w-4xl mx-auto"
              onClick={() => isDeleteConfirming && setIsDeleteConfirming(false)}
            >
              <div className="p-1.5 flex justify-center"><div className="w-10 h-1 bg-[#eae2e8] rounded-full"></div></div>
              {isEditing ? (
                <div className="p-4">
                  <h3 className="text-xs font-bold text-[#d58f99] uppercase tracking-wider mb-2">Editing</h3>
                  <textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    className="w-full bg-[#f9f6f7] rounded-xl p-3 border border-[#eae2e8] focus:border-[#d58f99] outline-none text-[#5a4a42] min-h-[100px] mb-3"
                  />
                  <div className="flex gap-2">
                    <Button variant="ghost" onClick={() => setIsEditing(false)} className="flex-1">Cancel</Button>
                    <Button onClick={handleSaveEdit} className="flex-1">Save</Button>
                  </div>
                </div>
              ) : (
                <div className="p-6">
                  {(selectedMsg.variants?.length || 0) > 1 && activeMode !== 'archive' && (
                    <div className="flex items-center justify-between bg-[#f9f6f7] p-2 rounded-xl mb-4 border border-[#eae2e8]">
                      <button onClick={prevVariant} disabled={!selectedMsg.selectedIndex} className="p-2 text-[#917c71] hover:text-[#d58f99] disabled:opacity-30"><Icons.ChevronLeft /></button>
                      <span className="text-xs font-bold text-[#5a4a42]">Variant {(selectedMsg.selectedIndex || 0) + 1} / {selectedMsg.variants?.length}</span>
                      <button onClick={nextVariant} disabled={(selectedMsg.selectedIndex || 0) >= (selectedMsg.variants?.length || 0) - 1} className="p-2 text-[#917c71] hover:text-[#d58f99] disabled:opacity-30"><Icons.ChevronRight /></button>
                    </div>
                  )}
                  <div className="grid grid-cols-4 gap-4">
                    <button onClick={(e) => { e.stopPropagation(); handleCopy(); }} className="flex flex-col items-center gap-2 group">
                      <div className="w-12 h-12 bg-[#f9f6f7] rounded-full flex items-center justify-center text-[#917c71] group-hover:bg-[#d58f99] group-hover:text-white transition-colors shadow-sm"><Icons.Copy /></div>
                      <span className="text-[10px] text-[#917c71]">Copy</span>
                    </button>

                    {activeMode !== 'archive' && canRegenerate && (
                      <button onClick={(e) => { e.stopPropagation(); handleRegenerate(); }} className="flex flex-col items-center gap-2 group">
                        <div className="w-12 h-12 bg-[#f9f6f7] rounded-full flex items-center justify-center text-[#917c71] group-hover:bg-[#d58f99] group-hover:text-white transition-colors shadow-sm"><Icons.Refresh /></div>
                        <span className="text-[10px] text-[#917c71]">Regen</span>
                      </button>
                    )}

                    {activeMode !== 'archive' && canBranch && !canRegenerate && (
                      <button onClick={(e) => { e.stopPropagation(); handleBranch(); }} className="flex flex-col items-center gap-2 group">
                        <div className="w-12 h-12 bg-[#f9f6f7] rounded-full flex items-center justify-center text-[#917c71] group-hover:bg-[#d58f99] group-hover:text-white transition-colors shadow-sm"><Icons.Branch /></div>
                        <span className="text-[10px] text-[#917c71]">Branch</span>
                      </button>
                    )}

                    <button onClick={(e) => { e.stopPropagation(); handleInitEdit(); }} className="flex flex-col items-center gap-2 group">
                      <div className="w-12 h-12 bg-[#f9f6f7] rounded-full flex items-center justify-center text-[#917c71] group-hover:bg-[#d58f99] group-hover:text-white transition-colors shadow-sm"><Icons.Edit /></div>
                      <span className="text-[10px] text-[#917c71]">Edit</span>
                    </button>

                    {selectedMsg.role === 'Wade' && activeMode !== 'archive' && (
                      <button onClick={(e) => { e.stopPropagation(); playTTS(); }} className="flex flex-col items-center gap-2 group">
                        <div className="w-12 h-12 bg-[#f9f6f7] rounded-full flex items-center justify-center text-[#917c71] group-hover:bg-[#d58f99] group-hover:text-white transition-colors shadow-sm"><Icons.VolumeLarge /></div>
                        <span className="text-[10px] text-[#917c71]">Speak</span>
                      </button>
                    )}

                    <button onClick={(e) => { e.stopPropagation(); handleFavorite(); }} className="flex flex-col items-center gap-2 group">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors shadow-sm ${selectedMsg.isFavorite ? 'bg-[#d58f99] text-white' : 'bg-[#f9f6f7] text-[#917c71] group-hover:bg-[#d58f99] group-hover:text-white'}`}><Icons.Heart filled={!!selectedMsg.isFavorite} /></div>
                      <span className="text-[10px] text-[#917c71]">Save</span>
                    </button>

                    <button onClick={(e) => { e.stopPropagation(); handleDelete(); }} className="flex flex-col items-center gap-2 group">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors shadow-sm ${isDeleteConfirming ? 'bg-red-500 text-white animate-pulse' : 'bg-[#f9f6f7] text-red-400 group-hover:bg-red-400 group-hover:text-white'}`}>{isDeleteConfirming ? <Icons.Check /> : <Icons.Trash />}</div>
                      <span className={`text-[10px] ${isDeleteConfirming ? 'text-red-500 font-bold' : 'text-[#917c71]'}`}>{isDeleteConfirming ? 'Confirm?' : 'Delete'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </>
        )
      }

      {/* Conversation Map Modal */}
      {
        showMap && (
          <>
            <div className="fixed inset-0 z-40 bg-black/20" onClick={() => setShowMap(false)} />
            <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-xl rounded-t-3xl shadow-2xl border-t border-[#eae2e8]/50 max-h-[70vh] overflow-hidden animate-slide-up">
              <div className="p-4 border-b border-[#eae2e8]/50 flex items-center justify-between">
                <h3 className="font-bold text-[#5a4a42] text-sm">Conversation GPS</h3>
                <button onClick={() => setShowMap(false)} className="w-7 h-7 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors">
                  <Icons.Close />
                </button>
              </div>
              <div className="overflow-y-auto p-4 space-y-2 max-h-[calc(70vh-60px)]">
                {displayMessages.map((msg) => {
                  const isLuna = msg.role === 'Luna';
                  return (
                    <div key={msg.id} className={`flex ${isLuna ? 'justify-end' : 'justify-start'}`}>
                      <button
                        onClick={() => scrollToMessage(msg.id)}
                        className={`text-left px-3 py-2 rounded-xl transition-all hover:scale-[1.02] ${isLuna
                          ? 'bg-[#d58f99]/20 border border-[#d58f99]/30 max-w-[85%]'
                          : 'bg-white border border-[#eae2e8] w-full'
                          }`}
                      >
                        <p className={`text-xs truncate ${isLuna ? 'text-[#5a4a42]' : 'text-[#917c71]'}`}>
                          {msg.text}
                        </p>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )
      }

      {/* Custom Prompt Editor Modal */}
      {
        showPromptEditor && (
          <>
            <div className="fixed inset-0 z-40 bg-black/20" onClick={() => setShowPromptEditor(false)} />
            <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-xl rounded-t-3xl shadow-2xl border-t border-[#eae2e8]/50 max-h-[60vh] overflow-hidden animate-slide-up">
              <div className="p-4 border-b border-[#eae2e8]/50 flex items-center justify-between">
                <h3 className="font-bold text-[#5a4a42] text-sm">Spice It Up</h3>
                <button onClick={() => setShowPromptEditor(false)} className="w-7 h-7 rounded-full bg-[#f9f6f7] flex items-center justify-center text-[#917c71] hover:bg-[#d58f99] hover:text-white transition-colors">
                  <Icons.Close />
                </button>
              </div>
              <div className="p-4 overflow-y-auto max-h-[calc(60vh-120px)]">
                <textarea
                  value={customPromptText}
                  onChange={(e) => setCustomPromptText(e.target.value)}
                  placeholder="Add extra instructions just for this conversation... Make Wade sassier? More romantic? Channel specific vibes? Type it here!"
                  className="w-full h-[200px] bg-[#f9f6f7] border border-[#eae2e8] rounded-2xl px-4 py-3 focus:outline-none focus:border-[#d58f99] text-[#5a4a42] text-sm placeholder-[#917c71]/50 resize-none"
                />
              </div>
              <div className="p-4 border-t border-[#eae2e8]/50 flex gap-2 justify-end">
                <button
                  onClick={() => setShowPromptEditor(false)}
                  className="px-4 py-2 text-sm text-[#917c71] hover:text-[#5a4a42] transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    if (activeSessionId) {
                      await updateSession(activeSessionId, { customPrompt: customPromptText });
                    }
                    setShowPromptEditor(false);
                  }}
                  className="px-4 py-2 bg-[#d58f99] text-white rounded-full text-sm font-bold hover:bg-[#c07a84] transition-colors shadow-sm"
                >
                  Save Spice
                </button>
              </div>
            </div>
          </>
        )
      }

      {/* Input Area - Hidden in Archive Mode */}
      {
        activeMode !== 'archive' && (
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-white border-t border-[#eae2e8] z-30">
            <div className="flex gap-2 max-w-4xl mx-auto items-end">
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={activeMode === 'sms' ? "Text message..." : "Type a message..."}
                rows={1}
                className="flex-1 bg-[#f9f6f7] border border-[#eae2e8] rounded-3xl px-5 py-3 focus:outline-none focus:border-[#d58f99] text-[#5a4a42] placeholder-[#917c71]/50 shadow-inner resize-none overflow-y-auto min-h-[48px] max-h-[120px]"
              />
              <Button
                onClick={(isTyping || waitingForSMS) ? handleCancel : handleSend}
                className="w-12 h-12 !px-0 rounded-full flex items-center justify-center shadow-md mb-0 transition-all"
              >
                {(isTyping || waitingForSMS) ? <Icons.Stop /> : <Icons.Send />}
              </Button>
            </div>
          </div>
        )
      }
    </div >
  );
};
